stop_advertising
----------------
.. currentmodule:: bluetooth

.. autofunction:: stop_advertising